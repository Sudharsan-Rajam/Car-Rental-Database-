<html>
<head>
<title>Rent a Car</title>
<style>
body{
	font-family:Arial;
	
}
</style>
</head>
<body>
<div style='margin:auto;border:2px solid #8a8a8a;border-radius:10px;width:80%'>
<div style='float:left;'><img src='images/car.jpg' style='width:90px;'></div>
<div style="margin:auto;text-align:center;font-size:20px;font-weight:bold;padding:5px;border-bottom:1px solid #dfdfdf;">Rent a Car </div>
<table style='margin:auto;'><tr>
<td><a href='customeradd.php'>Customer Add</a>  | </td>
<td><a href='customerlist.php'>Customer List</a> | </td>
<td><a href='vehicleadd.php'>Vehicle Add</a> | </td>
<td><a href='vehiclelist.php'>Vehicle List</a> | </td>
<td><a href='rentallist.php'>Rental List</a> | </td>
<td><a href='rentavehicle.php'>Book a Vehicle</a></td>
</tr>
</table><br />&nbsp;<br />