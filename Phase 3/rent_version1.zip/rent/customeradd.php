<?php
include "menu.php";
?>
<form method='post' action='customersave.php'>
<table style="margin:auto;width:500px;" cellpadding="5" cellspacing="10">

<tr><th colspan='2'>Add a Customer<br />&nbsp;</th></tr>
<tr><th align='left'>Customer ID</th><td><input type='text' name='customerid'></td></tr>
<tr><th align='left'>Customer Name</th><td><input type='text' name='customername'></td></tr>
<tr><th align='left'>Mobile Phone</th><td><input type='text' name='customerphone'></td></tr>
<tr><th align='center' colspan='2'><input type='Submit' Value='Save'></th></tr>
</table></td>
</tr>
</table>
</form>
