<?php

include "dbconn.php";

$vehicleid=$_POST["vehicleid"];
$fromdate=$_POST["fromdate"];
$todate=$_POST["todate"];
$customerid=$_POST["customerid"];
$rent=$_POST["rent"];

echo $insquery="insert into availability_info (ref_vehicle_id, start_date, return_date, no_of_days) values ('".$vehicleid."','".$fromdate."','".$todate."',DATEDIFF('".$todate."','".$fromdate."'))";
$result = $conn->query($insquery);

echo $insquery="insert into rental_info (ref_vehicle_id, ref_customer_id, start_date, return_date, order_date, total_amount) values ('".$vehicleid."','".$customerid."','".$fromdate."','".$todate."',date(now()),'".$rent."' )";
$result = $conn->query($insquery);



if ($result)
echo "<script>alert('Rental saved Successfully')</script>";
else
echo "<script>alert('Please try again')</script>";

echo "<script>location.href='rentavehicle.php'</script>";
?>


