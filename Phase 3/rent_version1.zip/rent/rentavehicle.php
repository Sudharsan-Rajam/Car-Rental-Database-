<?php
include "menu.php";
include "dbconn.php";
?>
<form method="post" action="rentavehiclesave.php">
<table style="margin:auto;width:500px;"  cellpadding="5" cellspacing="10">
<tr><th colspan='2'>Book a Vehicle<br />&nbsp;</th></tr>
<tr><th align='left'>Vehicle Number</th><td colspan='2'>
<select name='vehicleid'>
<?php
$sql = "select (v.vehicle_id) as vehicleid, v.vehicle_description from  vehicle_info v ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
  echo "<option value='".$row["vehicleid"]."'>".$row["vehicleid"]." - ".$row["vehicle_description"]."</option>";
  }
  }
	  ?>
</select>
</td></tr>
<tr><th align='left'>Rent Period</th><td>From<br /><input type='date' name='fromdate' placeholder="YYYY-MM-DD"></td><td>To<br /><input type='date' name='todate'  placeholder="YYYY-MM-DD"></td></tr>
<tr><th align='left'>Customer ID</th><td colspan='2'>
<select name='customerid'>
<?php
$sql = "select c.customer_id as customerid, c.customer_name as customername from customer_info c";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
  echo "<option value='".$row["customerid"]."'>".$row["customerid"]." - ".$row["customername"]."</option>";
  }
  }
	  ?>
</select></td></tr>
<tr><th align='left'>Customer ID</th><td colspan='2'><input type='number' name='rent'></td></tr>
<tr><th colspan='2' align="center"><input type='Submit' Value='Book'></th></tr>

</table>
</tr>
</table>
</form>